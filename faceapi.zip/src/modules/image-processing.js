import "../config/face-api";
import * as faceapi from "@vladmandic/face-api";
import { db } from "../config/firebase";
import { child, get, ref } from "firebase/database";
import { loadImage } from "canvas";
import { Hono } from "hono";

const dbRef = ref(db);

const getLabels = () =>
	get(child(dbRef, "UsersData/")).then((snapshot) => {
		if (snapshot.exists())
			return Object.values(snapshot.val()).map((_) => (_).name);
		throw new Error("Failed to load labels");
	});

const labels = await getLabels();

const loadModels = async () => {
	const modelPath = "https://ruisantosdotme.github.io/face-api.js/weights/";
	try {
		await Promise.all([
			faceapi.nets.faceRecognitionNet.loadFromUri(modelPath),
			faceapi.nets.faceLandmark68Net.loadFromUri(modelPath),
			faceapi.nets.ssdMobilenetv1.loadFromUri(modelPath),
		]);
		console.log("Models loaded successfully.");
	} catch (error) {
		throw new Error(`Error loading face-api models: ${error}`);
	}
};

await loadModels();

const loadLabeledImages = async () => {
	const descriptions = await Promise.all(
		labels.map(async (label) => {
			const labelledImage = await loadImage(
				`https://firebasestorage.googleapis.com/v0/b/bodycam1001.appspot.com/o/images%2F${label}.jpg?alt=media`,
			);
			const detections = await faceapi
				.detectSingleFace(labelledImage)
				.withFaceLandmarks()
				.withFaceDescriptor();
			if (!detections) {
				console.warn(`Failed to create detections for ${label}`);
				return null;
			}
			return new faceapi.LabeledFaceDescriptors(label, [detections.descriptor]);
		}),
	);

	return descriptions.filter((d) => !!d);
};

const labeledFaceDescriptors = await loadLabeledImages();

export const router = new Hono().post("/stream", async (c) => {
	const { image: rawImage } = await c.req.parseBody();
	if (!(rawImage instanceof File))
		return c.json({ error: "Invalid data" }, 400);

	const image = await loadImage(Buffer.from(await rawImage.arrayBuffer()));

	const detections = await faceapi
		.detectAllFaces(image)
		.withFaceLandmarks()
		.withFaceDescriptors();

	if (detections.length === 0)
		return c.json({ message: "No detections found" }, 400);

	const faceMatcher = new faceapi.FaceMatcher(labeledFaceDescriptors, 0.6);
	const results = detections.map((d) =>
		faceMatcher.findBestMatch(d.descriptor),
	);

	for (const result of results) {
		if (result.label !== "unknown") {
			console.log(`Recognized: ${result.label}`);
			// you'll probably do the TG sending logic here
			return c.json({ message: "Face recognized" });
		}
	}

	return c.json({ message: "Face not recognized" }, 400);
});
